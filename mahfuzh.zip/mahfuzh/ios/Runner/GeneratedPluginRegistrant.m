//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<animated_theme_switcher/AnimatedThemeSwitcherPlugin.h>)
#import <animated_theme_switcher/AnimatedThemeSwitcherPlugin.h>
#else
@import animated_theme_switcher;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [AnimatedThemeSwitcherPlugin registerWithRegistrar:[registry registrarForPlugin:@"AnimatedThemeSwitcherPlugin"]];
}

@end
